#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include "Student.h"
#include "BasicInfo.h"
#include "Date.h"
#include "Income2.h"
#include "Foreign.h"

using namespace std;

int main(){

return 0;	
}
